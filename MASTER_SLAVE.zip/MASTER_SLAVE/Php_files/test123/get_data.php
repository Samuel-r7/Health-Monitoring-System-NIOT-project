<?php
$servername = "localhost";
$username = "root";
$password = "12345678";
$dbname = "sensor_db";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["slave_id"])) {
    $selected_slave_id = $_POST["slave_id"];

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT SLAVE_ID, BPM, SPO2, TEMPERATURE, DATETIME FROM max_30102 WHERE SLAVE_ID = '$selected_slave_id' ORDER BY ID DESC LIMIT 10";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $tableData = '<tr>
                        <th>SLAVE_ID</th>
                        <th>BPM</th>
                        <th>SPO2</th>
                        <th>TEMPERATURE</th>
                        <th>Date & Time</th>
                     </tr>';

        while ($row = $result->fetch_assoc()) {
            $tableData .= '<tr>
                            <td>' . $row["SLAVE_ID"] . '</td>
                            <td>' . $row["BPM"] . '</td>
                            <td>' . $row["SPO2"] . '</td>
                            <td>' . $row["TEMPERATURE"] . '</td>
                            <td>' . $row["DATETIME"] . '</td>
                          </tr>';
        }

        echo $tableData;
    } else {
        echo "No data available for the selected SLAVE_ID.";
    }

    $conn->close();
}
?>
