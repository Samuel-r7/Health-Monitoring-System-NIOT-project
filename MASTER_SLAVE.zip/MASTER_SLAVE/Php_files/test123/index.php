<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css" media="screen"/>
    <title>Sensor Data</title>
</head>

<body>
    <h3>HEALTH MONITORING SYSTEM</h3>
	<h6>National Institute Of Ocean Technology</h6>
    <!--<h5>Allen | Samuel | Sabaresh | Sabbariesh | Annie</h5>-->

    <div class="button-container">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "12345678";
        $dbname = "sensor_db";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve distinct SLAVE_ID values for the buttons
        $sql_distinct = "SELECT DISTINCT SLAVE_ID FROM max_30102";
        $distinct_results = $conn->query($sql_distinct);

        echo '<form id="slaveIdForm">';
        while ($row = $distinct_results->fetch_assoc()) {
            $row_SLAVE_ID = $row["SLAVE_ID"];
            echo '<button class="button" type="button" onclick="fetchData(\'' . $row_SLAVE_ID . '\')">SLAVE_ID ' . $row_SLAVE_ID . '</button>';
        }
        echo '</form>';

        $conn->close();
        ?>
    </div>

    <table cellspacing="5" cellpadding="5" id="sensorTable">
        <tr>
            <th>SLAVE_ID</th>
            <th>BPM</th>
            <th>SPO2</th>
            <th>TEMPERATURE</th>
            <th>Date & Time</th>
        </tr>
    </table>

    <script>
        function fetchData(slaveId) {
            const sensorTable = document.getElementById("sensorTable");
            const xhr = new XMLHttpRequest();

            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    sensorTable.innerHTML = xhr.responseText;
                }
            };

            xhr.open("POST", "get_data.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.send("slave_id=" + slaveId);
        }

        // Initialize the table content with the first SLAVE_ID
        fetchData(1); // Replace 1 with the initial SLAVE_ID if needed
    </script>
</body>
</html>
