<?php
$hostname = "localhost";
$username = "root";
$password = "12345678";
$database = "sensor_db";

$conn = mysqli_connect($hostname, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Database connection is OK<br>";

if(isset($_POST["SLAVE_ID"]) && isset($_POST["BPM"]) && isset($_POST["SPO2"]) && isset($_POST["TEMPERATURE"])) {

    $slave_id = $_POST["SLAVE_ID"];
    $bpm = $_POST["BPM"];
    $temperature = $_POST["TEMPERATURE"];
    $spo2 = $_POST["SPO2"];

    $sql = "INSERT INTO max_30102 (SLAVE_ID, BPM, SPO2, TEMPERATURE) VALUES (".$slave_id.", ".$bpm.", ".$spo2.", ".$temperature.")";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " .$sql . "<br>" . mysqli_error($conn);
    }

}
?>